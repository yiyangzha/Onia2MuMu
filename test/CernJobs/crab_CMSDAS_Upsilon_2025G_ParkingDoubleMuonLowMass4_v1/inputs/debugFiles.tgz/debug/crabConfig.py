from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'CMSDAS_Upsilon_2025G_ParkingDoubleMuonLowMass4_v1'
config.General.workArea = 'CernJobs'
config.General.transferLogs = True
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.outputFiles = ['rootuple.root']
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'run_upsilon.py'
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.unitsPerJob = 1
config.Data.publication = False
config.Data.inputDataset = '/ParkingDoubleMuonLowMass4/Run2025G-PromptReco-v1/MINIAOD'
config.Data.outputDatasetTag = 'CMSDAS_Upsilon_2025G_ParkingDoubleMuonLowMass4_v1'
config.Data.inputDBS = 'global'
config.Data.lumiMask = 'Cert_Collisions2025_391658_398903_Muon.json'
config.Data.outLFNDirBase = '/store/user/yiyangz/Research/CMSDAS/'
config.section_('Site')
config.Site.storageSite = 'T2_CN_Beijing'
config.section_('User')
config.section_('Debug')
