from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'CMSDAS_Upsilon_2025G_ParkingDoubleMuonLowMass0_v0'
config.General.workArea = 'CernJobs'
config.General.transferOutputs = True
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'run_upsilon.py'
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['rootuple.root']
config.section_('Data')
config.Data.publication = False
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/user/yiyangz/CMSDAS/ntuple_production/ntuple/'
config.Data.splitting = 'FileBased'
config.Data.inputDataset = '/ParkingDoubleMuonLowMass0/Run2025G-PromptReco-v1/MINIAOD'
config.Data.outputDatasetTag = 'CMSDAS_Upsilon_2025G_ParkingDoubleMuonLowMass0_v0'
config.Data.lumiMask = 'Cert_Collisions2025_391658_398903_Muon.json'
config.Data.unitsPerJob = 1
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
