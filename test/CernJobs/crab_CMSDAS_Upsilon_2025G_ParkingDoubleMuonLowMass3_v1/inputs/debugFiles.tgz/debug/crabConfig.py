from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.workArea = 'CernJobs'
config.General.requestName = 'CMSDAS_Upsilon_2025G_ParkingDoubleMuonLowMass3_v1'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.outputFiles = ['rootuple.root']
config.JobType.psetName = 'run_upsilon.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.splitting = 'FileBased'
config.Data.outLFNDirBase = '/store/user/yiyangz/Research/CMSDAS/'
config.Data.inputDataset = '/ParkingDoubleMuonLowMass3/Run2025G-PromptReco-v1/MINIAOD'
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = 'CMSDAS_Upsilon_2025G_ParkingDoubleMuonLowMass3_v1'
config.Data.publication = False
config.Data.lumiMask = 'Cert_Collisions2025_391658_398903_Muon.json'
config.section_('Site')
config.Site.storageSite = 'T2_CN_Beijing'
config.section_('User')
config.section_('Debug')
