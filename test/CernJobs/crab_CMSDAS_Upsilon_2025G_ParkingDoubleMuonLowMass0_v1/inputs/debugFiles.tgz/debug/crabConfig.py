from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.requestName = 'CMSDAS_Upsilon_2025G_ParkingDoubleMuonLowMass0_v1'
config.General.workArea = 'CernJobs'
config.section_('JobType')
config.JobType.outputFiles = ['rootuple.root']
config.JobType.psetName = 'run_upsilon.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.publication = False
config.Data.inputDataset = '/ParkingDoubleMuonLowMass0/Run2025G-PromptReco-v1/MINIAOD'
config.Data.lumiMask = 'Cert_Collisions2025_391658_398903_Muon.json'
config.Data.splitting = 'FileBased'
config.Data.unitsPerJob = 1
config.Data.outputDatasetTag = 'CMSDAS_Upsilon_2025G_ParkingDoubleMuonLowMass0_v1'
config.Data.outLFNDirBase = '/store/user/yiyangz/Research/CMSDAS/'
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T2_CN_Beijing'
config.section_('User')
config.section_('Debug')
