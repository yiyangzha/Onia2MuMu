import FWCore.ParameterSet.Config as cms

def MMproducer(*args, **kwargs):
  mod = cms.EDProducer('MMproducer',
    muons = cms.required.InputTag,
    beamspot = cms.required.InputTag,
    primaryvertices = cms.required.InputTag,
    dimuonselection = cms.required.string,
    resolvePUambiguity = cms.required.bool,
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
