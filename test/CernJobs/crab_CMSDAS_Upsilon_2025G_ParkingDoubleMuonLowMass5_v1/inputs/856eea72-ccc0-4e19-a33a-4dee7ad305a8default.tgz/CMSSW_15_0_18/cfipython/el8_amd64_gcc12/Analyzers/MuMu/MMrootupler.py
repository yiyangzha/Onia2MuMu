import FWCore.ParameterSet.Config as cms

def MMrootupler(*args, **kwargs):
  mod = cms.EDAnalyzer('MMrootupler',
    dimuons = cms.required.InputTag,
    primaryVertices = cms.required.InputTag,
    TriggerResults = cms.required.InputTag,
    onia_pdgid = cms.required.uint32,
    onia_mass_cuts = cms.required.vdouble,
    FilterNames = cms.required.vstring,
    isMC = cms.required.bool,
    only_best = cms.required.bool,
    only_gen = cms.required.bool,
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
