import FWCore.ParameterSet.Config as cms

def MMfilter(*args, **kwargs):
  mod = cms.EDProducer('MMfilter',
    dimuons = cms.required.InputTag,
    muonSelection = cms.required.string,
    mmSelection = cms.required.string,
    do_trigger_match = cms.required.bool,
    HLT_filters = cms.required.vstring,
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
