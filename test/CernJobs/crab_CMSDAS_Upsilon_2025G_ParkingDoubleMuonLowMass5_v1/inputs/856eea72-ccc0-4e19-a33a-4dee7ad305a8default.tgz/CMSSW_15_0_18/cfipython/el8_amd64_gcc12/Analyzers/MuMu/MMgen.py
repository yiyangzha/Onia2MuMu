import FWCore.ParameterSet.Config as cms

def MMgen(*args, **kwargs):
  mod = cms.EDAnalyzer('MMgen',
    src = cms.required.InputTag,
    pdgid = cms.required.uint32,
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
