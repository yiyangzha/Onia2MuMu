from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.requestName = 'CMSDAS_Upsilon_2025G_ParkingDoubleMuonLowMass7_v1'
config.General.workArea = 'CernJobs'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['rootuple.root']
config.JobType.psetName = 'run_upsilon.py'
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.inputDataset = '/ParkingDoubleMuonLowMass7/Run2025G-PromptReco-v1/MINIAOD'
config.Data.lumiMask = 'Cert_Collisions2025_391658_398903_Muon.json'
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = 'CMSDAS_Upsilon_2025G_ParkingDoubleMuonLowMass7_v1'
config.Data.outLFNDirBase = '/store/user/yiyangz/Research/CMSDAS/'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T2_CN_Beijing'
config.section_('User')
config.section_('Debug')
